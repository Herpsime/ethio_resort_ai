const express = require("express");
const app = express();
const cors = require("cors"); // Add this for frontend requests

app.use(cors()); // Allow frontend to connect
app.use(express.json());
app.use(express.static(".")); // Serve HTML files

// hotel data
let currentDemand = "high";

const hotelData = {
  occupancy: 90,
  guests: 160,
  staff: 22,
  maintenance: 3,
  basePrices: { low: 800, medium: 1200, high: 1800 },
  customerSegments: [
    { label: "Business", discount: 10 },
    { label: "Leisure", discount: 5 },
  ],
};

// users
const users = [
  { id: 1, name: "Admin", email: "admin@ethio.com", password: "admin123" },
  { id: 2, name: "Demo", email: "demo@ethio.com", password: "demo123" },
];
let nextUserId = 3;

// login api
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  console.log("Login attempt:", email); // Debug log

  const user = users.find((u) => u.email === email && u.password === password);

  if (user) {
    res.json({
      success: true,
      message: `Welcome ${user.name}!`,
      token: `jwt_${user.id}_${Date.now()}`,
      user: { id: user.id, name: user.name, email: user.email },
    });
  } else {
    res.status(401).json({
      success: false,
      message: "Invalid email/password",
    });
  }
});

// register
app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  console.log("Register attempt:", email); // Debug log

  if (users.find((u) => u.email === email)) {
    return res.status(400).json({
      success: false,
      message: "Email already registered!",
    });
  }

  const newUser = {
    id: nextUserId++,
    name,
    email,
    password,
  };
  users.push(newUser);

  res.json({
    success: true,
    message: `${name} registered successfully! Please login.`,
    user: newUser,
  });
});

// pricing api
app.get("/api/pricing", (req, res) => {
  const demand = req.query.demand || currentDemand;
  let multiplier = demand === "low" ? 0.9 : demand === "high" ? 1.2 : 1;
  const prices = {
    low: Math.round(hotelData.basePrices.low * multiplier),
    medium: Math.round(hotelData.basePrices.medium * multiplier),
    high: Math.round(hotelData.basePrices.high * multiplier),
  };
  res.json({
    currentDemand: demand,
    prices,
    aiSuggestion:
      demand === "high"
        ? "High demand - Increase prices"
        : "Low demand - Consider discounts",
    customerSegments: hotelData.customerSegments,
  });
});

// dashboard api
app.get("/api/dashboard", (req, res) => {
  res.json(
    currentDemand === "high"
      ? { occupancy: 90, guests: 160, staff: 22, maintenance: 3 }
      : { occupancy: 60, guests: 90, staff: 12, maintenance: 1 },
  );
});

// update demand
app.post("/api/demand", (req, res) => {
  currentDemand = req.body.demand || "medium";
  console.log("Demand updated to:", currentDemand); // Debug
  res.json({ success: true, currentDemand });
});

// chatbot api
app.post("/api/chat", (req, res) => {
  const { message } = req.body;
  const lowerMsg = message.toLowerCase();
  let reply = "Ask about rooms, prices, food, spa, or booking!";

  if (lowerMsg.includes("room") || lowerMsg.includes("price")) {
    reply = `Rooms: ${hotelData.basePrices.low}-${hotelData.basePrices.high} ETB. Current demand: ${currentDemand}`;
  } else if (lowerMsg.includes("book")) {
    reply = "Use booking page or tell me room type + nights!";
  } else if (lowerMsg.includes("food")) {
    reply = "Ethiopian Injera + International cuisine. 7AM-10PM";
  } else if (lowerMsg.includes("coffee")) {
    reply = "Ethiopian coffee ceremony - 4PM daily!";
  } else if (lowerMsg.includes("spa")) {
    reply = "Massage, sauna, jacuzzi - Book now!";
  }

  res.json({ reply });
});

// booking api
app.post("/api/book", (req, res) => {
  const { name, email, roomType, days } = req.body;
  const base = hotelData.basePrices[roomType] || 1200;
  const multiplier =
    currentDemand === "high" ? 1.2 : currentDemand === "low" ? 0.9 : 1;
  const total = Math.round(base * multiplier * parseInt(days));
  const bookingId = "BOOK-" + Date.now();

  console.log("Booking:", bookingId, total); // Debug

  res.json({
    message: `${name}, booking ${bookingId} confirmed! Total: ${total} ETB`,
    bookingId,
    total: `${total} ETB`,
  });
});

// Test endpoint
app.get("/api/test", (req, res) => {
  res.json({ message: "Backend working! 🎉", demand: currentDemand });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`📱 Test: http://localhost:${PORT}/api/test`);
});
