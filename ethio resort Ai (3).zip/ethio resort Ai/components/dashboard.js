// ===============================
// 🧠 DASHBOARD CONTROLLER
// ===============================

// ---------- HELPERS ----------
function $(id) {
    return document.getElementById(id);
}

function setText(el, val) {
    if (el) el.innerText = val;
}

// ---------- STATE ----------
let currentDemand = "high";

// ===============================
// 📊 KPI SYSTEM
// ===============================
function updateKPIs() {
    const occupancy = $('occupancyValue');
    const guests = $('guestsValue');
    const staff = $('staffValue');
    const maintenance = $('maintenanceValue');

    if (!occupancy) return;

    let occ = 80, gst = 140, stf = 18, mnt = 2;

    if (currentDemand === "high") {
        occ = 92;
        gst = 170;
        stf = 24;
        mnt = 3;
    } 
    else if (currentDemand === "low") {
        occ = 55;
        gst = 85;
        stf = 12;
        mnt = 1;
    }

    setText(occupancy, occ + "%");
    setText(guests, gst);
    setText(staff, stf);
    setText(maintenance, mnt);
}

// ===============================
// 📊 WEEKLY BAR CHART
// ===============================
function renderBars() {
    const container = $('weeklyBars');
    if (!container) return;

    const data = currentDemand === "high"
        ? [90, 120, 140, 130, 160, 180, 170]
        : currentDemand === "low"
        ? [40, 60, 50, 70, 80, 75, 65]
        : [60, 80, 100, 90, 120, 150, 130];

    container.innerHTML = "";

    data.forEach(val => {
        const bar = document.createElement("div");
        bar.className = "bar";
        bar.style.height = val / 2 + "px";
        container.appendChild(bar);
    });
}

// ===============================
// 🤖 AI INSIGHT MESSAGE
// ===============================
function updateInsight() {
    const insight = $('dashboardInsight');

    if (!insight) return;

    insight.innerText =
        currentDemand === "high"
        ? "🔥 High demand detected. Consider increasing prices and adding staff."
        : currentDemand === "low"
        ? "📉 Demand is low. Offer discounts and promotions."
        : "⚖️ Demand is stable. Maintain current operations.";
}

// ===============================
// 🎛 DEMAND SWITCH BUTTONS
// ===============================
function initControls() {
    document.querySelectorAll('.demand-btn').forEach(btn => {
        btn.addEventListener('click', () => {

            currentDemand = btn.dataset.demand;

            document.querySelectorAll('.demand-btn')
                .forEach(b => b.classList.remove('active'));

            btn.classList.add('active');

            updateKPIs();
            renderBars();
            updateInsight();
        });
    });
}

// ===============================
// 🚀 INIT DASHBOARD
// ===============================
document.addEventListener("DOMContentLoaded", () => {
    updateKPIs();
    renderBars();
    updateInsight();
    initControls();
})