// ===============================
// 💰 SMART PRICING SYSTEM
// ===============================

// ---------- HELPERS ----------
function $(id) {
    return document.getElementById(id);
}

function setText(el, value) {
    if (el) el.innerText = value;
}

// ---------- STATE ----------
let currentDemand = "high";

// Base prices
const basePrices = {
    low: 800,
    medium: 1200,
    high: 1800
};

// ===============================
// 📊 UPDATE PRICES
// ===============================
function updatePricing() {
    const lowEl = $('lowPrice');
    const mediumEl = $('mediumPrice');
    const highEl = $('highPrice');
    const suggestionEl = $('aiSuggestionMsg');

    if (!lowEl || !mediumEl || !highEl) return;

    let multiplier = 1;

    if (currentDemand === "high") {
        multiplier = 1.2;
    } else if (currentDemand === "low") {
        multiplier = 0.9;
    }

    const prices = {
        low: Math.round(basePrices.low * multiplier),
        medium: Math.round(basePrices.medium * multiplier),
        high: Math.round(basePrices.high * multiplier)
    };

    // Update UI
    setText(lowEl, prices.low + " ETB");
    setText(mediumEl, prices.medium + " ETB");
    setText(highEl, prices.high + " ETB");

    // AI suggestion
    if (suggestionEl) {
        suggestionEl.innerText =
            currentDemand === "high"
            ? "📈 High demand → increase prices"
            : currentDemand === "low"
            ? "📉 Low demand → reduce prices"
            : "⚖️ Prices are stable";
    }
}

// ===============================
// 🎛 DEMAND BUTTONS
// ===============================
function initDemandButtons() {
    const buttons = document.querySelectorAll('.demand-btn');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {

            // Change state
            currentDemand = btn.dataset.demand;

            // Remove active class
            buttons.forEach(b => b.classList.remove('active'));

            // Add active to clicked
            btn.classList.add('active');

            // Update prices
            updatePricing();
        });
    });
}

// ===============================
// 🚀 INIT
// ===============================
document.addEventListener("DOMContentLoaded", () => {
    initDemandButtons();
    updatePricing();
});