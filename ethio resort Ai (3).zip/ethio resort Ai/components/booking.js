// ===============================
// 📅 BOOKING SYSTEM - API POWERED
// ===============================

function $(id) {
  return document.getElementById(id);
}

const form = $("bookingForm");
const roomType = $("roomType");
const daysInput = $("days");
const totalEl = $("totalPrice");
const successMsg = $("successMsg");

let currentDemand = "medium";

// ===============================
// 💰 CALCULATE PRICE (YOUR API)
async function calculateTotal() {
  const type = roomType.value;
  const days = parseInt(daysInput.value);

  if (!type || !days || days <= 0) {
    totalEl.innerText = "Total: 0 ETB";
    return;
  }

  try {
    const data = await fetch(`/api/pricing?demand=${currentDemand}`).then((r) =>
      r.json(),
    );
    const base =
      data.prices[
        type === "low" ? "low" : type === "medium" ? "medium" : "high"
      ];
    const total = Math.round(base * days);
    totalEl.innerText = `Total: ${total} ETB`;
  } catch (e) {
    totalEl.innerText = "Total: 0 ETB";
  }
}

// ===============================
// 🎛 EVENTS
roomType.addEventListener("change", calculateTotal);
daysInput.addEventListener("input", calculateTotal);

// ===============================
// 📤 FORM SUBMIT (YOUR API)
form.addEventListener("submit", async function (e) {
  e.preventDefault();

  const name = $("name").value.trim();
  const email = $("email").value.trim();

  if (!name || !email || !roomType.value || !daysInput.value) {
    successMsg.style.color = "red";
    successMsg.innerText = "⚠️ Please fill all fields!";
    return;
  }

  try {
    const data = await fetch("/api/book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        email,
        roomType: roomType.value,
        days: daysInput.value,
      }),
    }).then((r) => r.json());

    successMsg.style.color = "green";
    successMsg.innerText = data.message || "✅ Booking successful!";
    form.reset();
    totalEl.innerText = "Total: 0 ETB";
  } catch (e) {
    successMsg.style.color = "red";
    successMsg.innerText = "❌ Booking failed! Try again.";
  }
});