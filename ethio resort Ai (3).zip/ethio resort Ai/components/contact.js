// ===============================
// 📩 CONTACT FORM LOGIC
// ===============================

function $(id) {
    return document.getElementById(id);
}

const form = $('contactForm');

if (form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = $('name').value.trim();
        const email = $('email').value.trim();
        const message = $('message').value.trim();

        let valid = true;

        // Clear errors
        $('nameError').innerText = '';
        $('emailError').innerText = '';
        $('messageError').innerText = '';
        $('successMsg').innerText = '';

        // Name validation
        if (!name) {
            $('nameError').innerText = "Name is required";
            valid = false;
        }

        // Email validation
        if (!email) {
            $('emailError').innerText = "Email is required";
            valid = false;
        } else if (!email.includes('@')) {
            $('emailError').innerText = "Enter a valid email";
            valid = false;
        }

        // Message validation
        if (!message) {
            $('messageError').innerText = "Message cannot be empty";
            valid = false;
        }

        if (!valid) return;

        // Simulated sending
        setTimeout(() => {
            $('successMsg').innerText =
                "✅ Message sent! Our AI concierge will respond soon.";

            form.reset();
        }, 500);
    });
}