// ===============================
// 🤖 CHATBOT LOGIC - API POWERED
// ===============================

// ---------- HELPERS ----------
function $(id) {
  return document.getElementById(id);
}

// ---------- ELEMENTS ----------
const chat = $("chatMessages");
const input = $("userInput");
const sendBtn = $("sendBtn");

// ===============================
// 💬 ADD MESSAGE
function addMessage(text, isUser = false) {
  const div = document.createElement("div");
  div.className = isUser ? "user" : "bot";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerText = text;

  div.appendChild(bubble);
  chat.appendChild(div);

  chat.scrollTop = chat.scrollHeight;
}

// ===============================
// 🧠 API‑POWERED REPLIES
async function getReply(msg) {
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: msg }),
    });
    const data = await response.json();
    return data.reply;
  } catch (e) {
    return "🤖 Sorry, connection issue. Try: rooms, prices, food, spa?";
  }
}

// ===============================
// 📤 SEND MESSAGE
async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;

  addMessage(text, true);
  input.value = "";

  // Show typing...
  const typingMsg = document.createElement("div");
  typingMsg.className = "bot";
  typingMsg.innerHTML = '<div class="bubble">🤖 typing...</div>';
  chat.appendChild(typingMsg);
  chat.scrollTop = chat.scrollHeight;

  // AI delay + API call
  setTimeout(async () => {
    chat.removeChild(typingMsg);
    const reply = await getReply(text);
    addMessage(reply);
  }, 800);
}

// ===============================
// 🎛 EVENTS
sendBtn.addEventListener("click", sendMessage);

input.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    sendMessage();
  }
});

// ===============================
// 🚀 INIT MESSAGE
window.onload = () => {
  addMessage(
    "👋 Welcome to Ethio Resort! Ask me about rooms, prices, food, spa, or coffee!",
  );
};
