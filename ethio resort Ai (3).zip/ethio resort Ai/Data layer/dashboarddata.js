// ===============================
// 📊 DASHBOARD DATA
// ===============================

const dashboardData = {

    high: {
        occupancy: 92,
        guests: 170,
        staff: 24,
        maintenance: 3,

        weekly: [90, 120, 140, 130, 160, 180, 170],

        insight: "🔥 High demand detected. Increase prices and staff."
    },

    medium: {
        occupancy: 80,
        guests: 140,
        staff: 18,
        maintenance: 2,

        weekly: [60, 80, 100, 90, 120, 150, 130],

        insight: "⚖️ Demand is stable. Maintain current operations."
    },

    low: {
        occupancy: 55,
        guests: 85,
        staff: 12,
        maintenance: 1,

        weekly: [40, 60, 50, 70, 80, 75, 65],

        insight: "📉 Low demand. Consider discounts and promotions."
    }

};