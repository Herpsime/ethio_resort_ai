// ===============================
// 🤖 CHATBOT DATA (KNOWLEDGE BASE)
// ===============================

const chatbotData = {
    
    greetings: [
        "👋 Hello! Welcome to Ethio Resort.",
        "Hi there! How can I assist you today?",
        "Welcome! Ask me anything about our services."
    ],

    rooms: [
        "🛏️ We offer rooms from 800 to 1800 ETB.",
        "Rooms include standard, medium, and luxury options.",
        "Prices depend on demand and availability."
    ],

    pricing: [
        "💰 Our pricing changes based on demand.",
        "Check the pricing page for live updates.",
        "High demand increases prices, low demand reduces them."
    ],

    food: [
        "🍽️ We serve Ethiopian and international cuisine.",
        "Enjoy fresh traditional meals and modern dishes.",
        "Our restaurant is open all day."
    ],

    spa: [
        "💆 Spa services include massage, sauna, and relaxation.",
        "Treat yourself with our wellness packages."
    ],

    coffee: [
        "☕ Ethiopian coffee ceremony is held daily.",
        "Experience traditional coffee culture every afternoon."
    ],

    booking: [
        "📅 You can book rooms on the booking page.",
        "Reservations are quick and easy online."
    ],

    fallback: [
        "🤖 I can help with rooms, pricing, food, spa, or booking.",
        "Try asking about our services or prices!",
        "I'm here to assist with your stay 😊"
    ]
};