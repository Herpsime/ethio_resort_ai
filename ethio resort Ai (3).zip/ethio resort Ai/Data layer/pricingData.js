// ===============================
// 💰 PRICING DATA
// ===============================

const pricingData = {

    basePrices: {
        low: 800,
        medium: 1200,
        high: 1800
    },

    multipliers: {
        high: 1.2,
        medium: 1,
        low: 0.9
    },

    messages: {
        high: "📈 High demand → increase prices",
        medium: "⚖️ Prices are stable",
        low: "📉 Low demand → reduce prices"
    }

};